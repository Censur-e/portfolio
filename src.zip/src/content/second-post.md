<!-----
title: Coding is Cool
description: Second post.
date: '2024-7-25'
categories:
  - sveltekit
  - svelte
published: true
---

## Svelte

Media inside the **static** folder is served from `/`.

![Svelte](/favicon.png)-->
