---
title: Sorti du Portfolio
description: Création de mon nouveau portfolio et va pouvoir me faire arriver dans le monde de la conception graphique.
date: '2024-12-14'
categories:
  - Portfolio
  - News
published: true
---

## Mon portfolio est là !
--

Bienvenue dans ce premier blog de mon portfolio qui signe la sorti de mon nouveau portfolio.

Je vais pouvoir maintenant travailler avec un magnifique portfolio fait en Svelte et SvelteKit.

<!--```svelte-
<script>
	export let name = 'Developers';

	function greet(name: string) {
		console.log(`Hey ${name}! 👋`);
	}
	let num = 0;
</script>
```--> 
